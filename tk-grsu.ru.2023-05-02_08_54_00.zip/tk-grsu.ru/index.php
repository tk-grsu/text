<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title>PAKKU SHOP</title>

    <link rel="shortcut icon" href=".png" type="image/png">
    <link rel="stylesheet" type="text/css" href="/css/index.css">

<meta name="viewport" content="width=device-width, initial-scale = 1.0">

</head>
<body>
    <!-- Шапка -->
    <header>
        <div class="fixed">
        <div class="header">
          <div class="container">
            <div class="name">
                <font class="name"><b>Pakku</b></font>
            </div>
                <div class="cart-button">
                    <img src="photo/cart-black.png" class="cart-black">
                </div>
        </div>
        </div>
        </div>
    </header>
<div class="btn1" align="center">
          <form action="sweatshirt.html"><button>SWEATSHIRT</button></form>
          &nbsp
          <form action="hoodie.html"><button>HOODIE</button></form>
          &nbsp
          <form action="t-shirt.html"><button>T-SHIRT</button></form>
</div>
<div class="btn2" align="center">
  <form action="bag.html"><button>BAGS</button></form>
  &nbsp
  <form action="zip-hoodie.html"><button>ZIP-HOODIE</button></form>
  &nbsp
  <form action="glasses.html"><button>GLASSES</button></form>
</div>


<!-- Бегущий текст -->
    <div class="marquee-infinite" id="ELFBAR">
      <div>
          <h1>Низкие цены! &nbsp &nbsp &nbsp &nbsp</h1>
          <h1>Низкие цены! &nbsp &nbsp &nbsp &nbsp</h1>
          <h1>Низкие цены! &nbsp &nbsp &nbsp &nbsp</h1>
          <h1>Низкие цены! &nbsp &nbsp &nbsp &nbsp</h1>
          <h1>Низкие цены! &nbsp &nbsp &nbsp &nbsp</h1>
          <h1>Низкие цены! &nbsp &nbsp &nbsp &nbsp</h1>
          <h1>Низкие цены! &nbsp &nbsp &nbsp &nbsp</h1>
          <h1>Низкие цены! &nbsp &nbsp &nbsp &nbsp</h1>
          <h1>Низкие цены! &nbsp &nbsp &nbsp &nbsp</h1>
          <h1>Низкие цены! &nbsp &nbsp &nbsp &nbsp</h1>
          <h1>Низкие цены! &nbsp &nbsp &nbsp &nbsp</h1>
          <h1>Низкие цены! &nbsp &nbsp &nbsp &nbsp</h1>
      </div>
  </div>

<!-- Начало основы -->
<div class="tovars" align="center">
<div align="center" valign="bottom" hieght="100%" class="1">
  <div class="card">
  <div class="card-img" background="https://snf-mall.com/wp-content/uploads/2020/09/118973399_692283768036756_8199443190674942991_n-850x850.jpg"></div>
  <div class="card-info">
    <p class="text-title"><font face="arial">ZIP-HOODIE - PESO</p>
    <p class="text-body">Отправка 1-3 дня</p>
  </div>
  <div class="card-footer">
  <span class="text-title2">$42</span>
  <div class="card-button">
    buy now
  </div>
</div></div>
</div>

&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

<div align="center" valign="bottom" hieght="100%" class="2">
  <div class="card">
  <div class="card-img2" background="https://snf-mall.com/wp-content/uploads/2020/09/118973399_692283768036756_8199443190674942991_n-850x850.jpg"></div>
  <div class="card-info">
    <p class="text-title"><font face="arial">HOODIE - CARHARTT</p>
    <p class="text-body">Отправка 1-3 дня</p>
  </div>
  <div class="card-footer">
  <span class="text-title2">$160</span>
  <div class="card-button">
    buy now
  </div>
</div></div>
</div>
</div>
</body>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<!-- КОРЗИНА -->




</body>
</html>